﻿namespace AlarmClock.Data;

public enum Music
{
    Analogue = 1,
    BedSide = 2,
    Electronic = 3,
    Ringtone = 4
}